import os
from socket import socket, AF_INET, SOCK_STREAM
from chinese_speech_recognition.general_function.file_wav import *

file_name = 'chinese_speech_recognition/demovedio/A2_107.wav'
sock = socket(AF_INET, SOCK_STREAM)
sock.connect(('127.0.0.1',50008))
sock.send(str.encode(file_name))

data = sock.recv(4096)
print('分析结果：',bytes.decode(data))
# import random
# print(random.uniform(0.4,0.8))