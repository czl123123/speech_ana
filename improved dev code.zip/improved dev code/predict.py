import argparse
import glob
import logging
import os
import json

import torch
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler,TensorDataset
from torch.utils.data.distributed import DistributedSampler
from tools.common import init_logger, logger

from models.transformers import WEIGHTS_NAME,BertConfig,AlbertConfig
from models.bert_for_ner import BertSpanForNer
from models.albert_for_ner import AlbertSpanForNer
from processors.utils_ner import CNerTokenizer, get_entities
from processors.ner_span import convert_examples_to_features, InputExample
from processors.ner_span import ner_processors as processors
from processors.ner_span import collate_fn
from processors.utils_ner import bert_extract_item

# ********** Parameters **********
ALL_MODELS = sum((tuple(conf.pretrained_config_archive_map.keys()) for conf in (BertConfig,AlbertConfig)), ())

MODEL_CLASSES = {
    ## bert ernie bert_wwm bert_wwwm_ext
    'bert': (BertConfig, BertSpanForNer, CNerTokenizer),
    'albert': (AlbertConfig,AlbertSpanForNer,CNerTokenizer)
}
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device('cpu')
model_type = 'bert'
model_name_or_path = './prev_trained_model/bert-base' # base model path
processor = processors['cluener']()
label_list = processor.get_labels()
id2label = {i: label for i, label in enumerate(label_list)}
num_labels = len(label_list)
output_dir = './outputs/cluener_output/bert/checkpoint-6720/' # finetuned model path
predict_checkpoints = 6720 # target checkpoints
max_seq_length = 512
task_name = 'cluener'
cache_dir = './CLUEdatasets/cluener/'

def load_and_cache_examples(sentence, task, tokenizer, data_type='train'):
    processor = processors[task]()
    # Load data features from cache or dataset file
    cached_features_file = os.path.join(cache_dir, 'cached_span-{}_{}_{}_{}'.format(
        data_type,
        list(filter(None, model_name_or_path.split('/'))).pop(),
        str(max_seq_length),
        str(task)))
    # if os.path.exists(cached_features_file):
    #     logger.info("Loading features from cached file %s", cached_features_file)
    #     features = torch.load(cached_features_file)
    # else:
    # logger.info("Creating features from dataset file failed")
    # label_list = processor.get_labels()
    examples = []

    # guid = "%s-%s" % (set_type, i)
    # text_a = line['words']
    # labels = line['labels']
    # subject = get_entities(labels,id2label=None,markup='bios')
    # examples.append(InputExample(guid=guid, text_a=text_a, subject=subject))
    guid = "predict case"
    token = tokenizer.tokenize(sentence)
    labels = [0] * len(token)
    subject = []
    examples.append(InputExample(guid=guid, text_a=token, subject=subject))
    # print(processor.get_test_examples(cache_dir))
   
    features = convert_examples_to_features(examples=examples,
                                            tokenizer=tokenizer,
                                            label_list=label_list,
                                            max_seq_length=max_seq_length,
                                            cls_token_at_end=bool(model_type in ["xlnet"]),
                                            pad_on_left=bool(model_type in ['xlnet']),
                                            cls_token = tokenizer.cls_token,
                                            cls_token_segment_id=2 if model_type in ["xlnet"] else 0,
                                            sep_token=tokenizer.sep_token,
                                            # pad on the left for xlnet
                                            pad_token=tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0],
                                            pad_token_segment_id=4 if model_type in ['xlnet'] else 0,
                                            )
        
    # Convert to Tensors and build dataset
    if data_type =='dev':
        return features
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_input_mask = torch.tensor([f.input_mask for f in features], dtype=torch.long)
    all_segment_ids = torch.tensor([f.segment_ids for f in features], dtype=torch.long)
    all_start_ids = torch.tensor([f.start_ids for f in features], dtype=torch.long)
    all_end_ids = torch.tensor([f.end_ids for f in features], dtype=torch.long)
    all_input_lens = torch.tensor([f.input_len for f in features], dtype=torch.long)
    dataset = TensorDataset(all_input_ids, all_input_mask, all_segment_ids, all_start_ids,all_end_ids,all_input_lens)
    return dataset

def predict(sentence, model, tokenizer, prefix=""):
    pred_output_dir = output_dir
    test_dataset = load_and_cache_examples(sentence, task_name, tokenizer, data_type='test')
    print(len(test_dataset))
    # Note that DistributedSampler samples randomly
    test_sampler = SequentialSampler(test_dataset)
    test_dataloader = DataLoader(test_dataset, sampler=test_sampler, batch_size=1,collate_fn=collate_fn)
    # Eval!
    logger.info("***** Running prediction %s *****", prefix)
    
    for step, batch in enumerate(test_dataloader):
        model.eval()
        batch = tuple(t.to(device) for t in batch)
        with torch.no_grad():
            inputs = {"input_ids": batch[0], "attention_mask": batch[1],"start_positions": None,"end_positions": None}
            if model_type != "distilbert":
                # XLM and RoBERTa don"t use segment_ids
                inputs["token_type_ids"] = (batch[2] if model_type in ["bert", "xlnet"] else None)
            outputs = model(**inputs)
        start_logits, end_logits = outputs[:2]
        R = bert_extract_item(start_logits, end_logits)
        if R:
            label_entities = [[id2label[x[0]],x[1],x[2]] for x in R]
        else:
            label_entities = []
        result = []
        for entity, i, j in label_entities:
            result.append([entity, sentence[int(i):int(j+1)]])
        print(result)


def main():
    config_class, model_class, tokenizer_class = MODEL_CLASSES[model_type]
    config = config_class.from_pretrained(model_name_or_path,
                                            num_labels=num_labels,loss_type = 'ce',
                                            soft_label = True)
    # tokenizer = tokenizer_class.from_pretrained(model_name_or_path,
    #                                             do_lower_case=True)
    model = model_class.from_pretrained(model_name_or_path,
                                        from_tf=bool(".ckpt" in model_name_or_path),
                                        config=config)
    model.to(device)

    tokenizer = tokenizer_class.from_pretrained(output_dir, do_lower_case=True)
    checkpoints = [output_dir]

    checkpoints = list(
        os.path.dirname(c) for c in sorted(glob.glob(output_dir + '/**/' + WEIGHTS_NAME, recursive=True)))

    logging.getLogger("transformers.modeling_utils").setLevel(logging.WARN)  # Reduce logging
    checkpoints = [x for x in checkpoints if x.split('-')[-1] == str(predict_checkpoints)]
    logger.info("Predict the following checkpoints: %s", checkpoints)

    for checkpoint in checkpoints:
        prefix = checkpoint.split('/')[-1] if checkpoint.find('checkpoint') != -1 else ""
        model = model_class.from_pretrained(checkpoint)
        model.to(device)
        predict(sentence, model, tokenizer, prefix=prefix)

if __name__ == "__main__":
    sentence = '我想应聘一个数据挖掘工程师的岗位。希望可以在玉山镇，淀山湖也行。工资的话我希望一个月能拿到五千到一万吧。'
    main()
    